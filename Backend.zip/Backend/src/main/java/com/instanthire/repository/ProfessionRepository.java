package com.instanthire.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.instanthire.model.Profession;

public interface ProfessionRepository extends JpaRepository<Profession, Long>{

}
