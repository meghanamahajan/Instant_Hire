package com.instanthire.controller;

public class CustomerController {

}
