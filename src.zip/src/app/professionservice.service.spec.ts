import { TestBed } from '@angular/core/testing';

import { ProfessionserviceService } from './professionservice.service';

describe('ProfessionserviceService', () => {
  let service: ProfessionserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProfessionserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
