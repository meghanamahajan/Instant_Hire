import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserLoginComponent } from './user-login/user-login.component';
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { EmployeeLoginComponent } from './employee-login/employee-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminRegistrationComponent } from './admin-registration/admin-registration.component'
import { EmployeeRegistrationComponent } from './employee-registration/employee-registration.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { HomepageComponent } from './homepage/homepage.component';
import { UserhomepageComponent } from './userhomepage/userhomepage.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { ProfessionalEmployeesComponent } from './professional-employees/professional-employees.component';
import { ConfirmEmployeeComponent } from './confirm-employee/confirm-employee.component';
import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { EmployeehomepageComponent } from './employeehomepage/employeehomepage.component';
import { EmployeeprofileComponent } from './employeeprofile/employeeprofile.component';
import { CustomerOrderlistComponent } from './customer-orderlist/customer-orderlist.component';
import { OrderRecieptComponent } from './order-reciept/order-reciept.component';
import { AdminOrderlistComponent } from './admin-orderlist/admin-orderlist.component';
import { EmployeeOrderlistComponent } from './employee-orderlist/employee-orderlist.component';
import { CustforgotpassComponent } from './custforgotpass/custforgotpass.component';
import { EmployeeNotificationComponent } from './employee-notification/employee-notification.component';
import { NewEmployeesComponent } from './new-employees/new-employees.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { EmployeeforgotpassComponent } from './employeeforgotpass/employeeforgotpass.component';
import { PaymentDetailsComponent } from './payment-details/payment-details.component';
import { PaymentReceiptComponent } from './payment-receipt/payment-receipt.component';
import { EmployeeByCityComponent } from './employee-by-city/employee-by-city.component';


const routes: Routes = [
  { path: 'ulogin', component: UserLoginComponent },
  { path: 'elogin', component: EmployeeLoginComponent },
  { path: 'alogin', component: AdminLoginComponent },
  { path: 'areg', component: AdminRegistrationComponent },
  { path: 'ereg', component: EmployeeRegistrationComponent },
  { path: 'ureg', component: UserRegistrationComponent },
  { path: 'emplist', component: EmployeeListComponent },
  { path: 'custlist', component: CustomerListComponent },
  { path: 'aboutus', component: AboutUsComponent },
  { path: 'contactus', component: ContactUsComponent },
  { path: 'custforgetpass', component: CustforgotpassComponent },
  { path: 'empforgetpass', component: EmployeeforgotpassComponent },
  { path: 'payment', component: PaymentDetailsComponent },
  { path: 'paymentrec', component: PaymentReceiptComponent },



  {
    path: 'home', component: HomepageComponent
  },
  {
    path: 'uhome', component: UserhomepageComponent, children: [
      { path: 'uprofile', component: UserprofileComponent },
      { path: "professional-emp/:id", component: ProfessionalEmployeesComponent },
      { path: "update-customer/:id", component: UpdateCustomerComponent },
      { path: "confirm-employee/:id", component: ConfirmEmployeeComponent },
      { path: 'customerorderlist', component: CustomerOrderlistComponent },
      { path: "order-reciept/:id", component: OrderRecieptComponent },
      { path: 'emplist', component: EmployeeListComponent },
      { path: 'forgetpass', component: CustforgotpassComponent },
      { path: 'viewemp/:id', component: ViewCustomerComponent },
      { path: "empcity/:city", component: EmployeeByCityComponent },

    ]
  },
  {
    path: 'ahome', component: AdminhomepageComponent, children: [
      { path: 'aprofile', component: AdminprofileComponent },
      { path: 'emplist', component: EmployeeListComponent },
      { path: 'custlist', component: CustomerListComponent },
      { path: 'viewcust/:id', component: ViewCustomerComponent },
      { path: 'viewemp/:id', component: ViewEmployeeComponent },
      { path: "professional-emp/:id", component: ProfessionalEmployeesComponent },
      { path: 'adminorderlist', component: AdminOrderlistComponent },
      { path: 'newemp', component: NewEmployeesComponent },



    ]
  },
  {
    path: 'ehome', component: EmployeehomepageComponent, children: [
      { path: 'eprofile', component: EmployeeprofileComponent },
      { path: "update-employee/:id", component: UpdateEmployeeComponent },
      { path: 'employeeorderlist', component: EmployeeOrderlistComponent },
      { path: 'employeenotifaction', component: EmployeeNotificationComponent },

    ]
  },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '404', component: ErrorpageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
