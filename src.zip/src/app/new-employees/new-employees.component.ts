import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { OrderDetails } from '../order-details';
import { OrderDetailsService } from '../order-details.service';
import { ProfessionserviceService } from '../professionservice.service';

@Component({
  selector: 'app-new-employees',
  templateUrl: './new-employees.component.html',
  styleUrls: ['./new-employees.component.css']
})
export class NewEmployeesComponent implements OnInit {

  profession: any;
  count: number = 1;
  mailId: string;
  undoneorders = false;
  emp: Employee[];
  emp1: Employee[];
  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,
    private router: Router,
    private customerService: CustomerService,
    private orderDetailsService: OrderDetailsService,
    private professionService: ProfessionserviceService) { }

  ngOnInit(): void {
    this.mailId = sessionStorage.getItem('sid');
    // console.log("mailId : == > " + this.mailId);

    if (this.mailId == null) {
      window.location.assign('elogin');
    } else {
      this.employeeService.getEmployeeByRating().subscribe(data => {
        this.emp1 = data;
        this.count = this.emp1.length;



      },
        error => console.log("error" + error)

      );
      if (this.count === 0) {
        (<HTMLInputElement>document.getElementById('notificationlist')).innerHTML = "No New Notifications";
        (<HTMLInputElement>document.getElementById('notificationlist')).style.fontSize = "50px";
        (<HTMLInputElement>document.getElementById('notificationlist')).style.textAlign = "center";
        (<HTMLInputElement>document.getElementById('notificationlist')).style.color = "red";
      }
    }
  }

  updateRating(id: number) {
    this.router.navigate(['ahome/viewemp', id]);
  }


}
