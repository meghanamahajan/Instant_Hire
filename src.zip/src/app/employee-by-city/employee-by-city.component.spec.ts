import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeByCityComponent } from './employee-by-city.component';

describe('EmployeeByCityComponent', () => {
  let component: EmployeeByCityComponent;
  let fixture: ComponentFixture<EmployeeByCityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeByCityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeByCityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
