import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-by-city',
  templateUrl: './employee-by-city.component.html',
  styleUrls: ['./employee-by-city.component.css']
})
export class EmployeeByCityComponent implements OnInit {
  imgid: any;
  retrievedImage: any;
  retrieveResonse: any;
  base64Data: any;
  employees: Employee[];
  constructor(private employeeService: EmployeeService,
    private router: Router,
    private route: ActivatedRoute,
    private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.getEmployees();
  }

  private getEmployees() {
    let cityN = this.route.snapshot.params["city"]
    this.employeeService.getEmployeeByCity(cityN).subscribe(data => {
      console.log(data);
      this.employees = data;
      for (let i = 0; i < this.employees.length; i++) {
        this.imgid = this.employees[i].employeeId;
        this.httpClient.get('http://localhost:8080/instanthire/image/show/' + this.imgid)
          .subscribe(
            res => {
              this.retrieveResonse = res;
              this.base64Data = this.retrieveResonse.picByte;
              this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
              this.employees[i].image = this.retrievedImage;
            }
          );
      }
    });
  }
  serachbyCity() {
    let city = (<HTMLInputElement>document.getElementById('employeeCity')).value;
    this.employeeService.getEmployeeByCity(city).subscribe(data => {
      // this.employee = data;
      this.router.navigate(['uhome/empcity', city]);

    },
      error => this.router.navigate(['uhome/emplist'])
    );
  }
}
