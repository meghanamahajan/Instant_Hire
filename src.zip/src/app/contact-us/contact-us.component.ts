import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FeedbackModel } from '../feedback-model';
import { FeedbackModelService } from '../feedback-model.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  feedbackModel: FeedbackModel = new FeedbackModel();
  constructor(private router: Router,
    private feedbackModelService: FeedbackModelService) { }

  ngOnInit(): void {
  }

  onsubmit() {
    console.log(this.feedbackModel.msg + " " + this.feedbackModel.emailId);
    this.feedbackModelService.addFeedback(this.feedbackModel).subscribe(data => {
      console.log("data = >" + data);
      window.alert("done");
      (<HTMLInputElement>document.querySelector("#emailId")).value = "";
      (<HTMLInputElement>document.querySelector("#msg")).value = "";
      if (sessionStorage.getItem('type') === "customer") {
        this.router.navigate(['uhome']);
      } else if (sessionStorage.getItem('type') === "admin") {
        this.router.navigate(['ahome']);
      } else if (sessionStorage.getItem('type') === "employee") {
        this.router.navigate(['home']);
      } else {
        this.router.navigate(['home']);
      }
    },
      error => window.alert("please try again!!!!!!!!")
    );


  }

}
