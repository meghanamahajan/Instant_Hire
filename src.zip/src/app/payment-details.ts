export class PaymentDetails {

    CUST_ID: string;

    TXN_AMOUNT: string;

    CHANNEL_ID: string;

    ORDER_ID: string;

    INDUSTRY_TYPE_ID: string;
}
