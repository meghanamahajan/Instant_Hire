import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { OrderDetails } from '../order-details';
import { OrderDetailsService } from '../order-details.service';

@Component({
  selector: 'app-confirm-employee',
  templateUrl: './confirm-employee.component.html',
  styleUrls: ['./confirm-employee.component.css']
})
export class ConfirmEmployeeComponent implements OnInit {

  imgid: any;
  retrievedImage: any;
  retrieveResonse: any;
  base64Data: any;
  id: number;
  isadmin: boolean = true;
  cid: number;
  customer: Customer = new Customer();
  employee: Employee = new Employee();
  orderDetails: OrderDetails = new OrderDetails();
  constructor(private employeeServie: EmployeeService,
    private customerService: CustomerService,
    private orderdetailsService: OrderDetailsService,
    private route: ActivatedRoute,
    private router: Router,
    private httpClient: HttpClient) { }

  ngOnInit(): void {
    if (sessionStorage.getItem('type') === "admin") {
      this.isadmin = false;
    }
    var email = sessionStorage.getItem('sid');
    if (email === null) {
      window.location.assign("/ulogin")
    } else {
      this.customerService.getCustomerByEmail(email).subscribe(data => {
        this.customer = data;
      })
      this.cid = this.route.snapshot.params['id'];
      this.getEmployee(this.cid);
    }
  }

  getEmployee(id: number) {
    this.employeeServie.getEmployeeById(id).subscribe(data => {
      this.employee = data;
      this.imgid = this.employee.employeeId;
      this.httpClient.get('http://localhost:8080/instanthire/image/show/' + this.imgid)
        .subscribe(
          res => {
            this.retrieveResonse = res;
            this.base64Data = this.retrieveResonse.picByte;
            this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
            this.employee.image = this.retrievedImage;
          }
        );
    });
  }
  confirmHire(id: number) {

    this.orderDetails.employeeId = id;
    this.orderDetails.customerId = this.customer.customerId;
    console.log(this.orderDetails);
    this.orderdetailsService.addorder(this.orderDetails).subscribe(data => {
      console.log(data);
      this.gotoPage();
    },
      error => console.log(error));
  }
  gotoPage() {
    this.router.navigate(['uhome']);
  }
}
