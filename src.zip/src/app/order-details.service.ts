import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { OrderDetails } from './order-details';

@Injectable({
  providedIn: 'root'
})
export class OrderDetailsService {

  private baseURL = "http://localhost:8080/instanthire/order/";
  constructor(private httpClient: HttpClient) { }

  addorder(orderDetails: OrderDetails): Observable<Object> {
    console.log("in addorder method");
    console.log(orderDetails);
    return this.httpClient.post(`${this.baseURL}/${"addorder"}`, orderDetails);


  }

  getOrderByCustomerId(id: number): Observable<OrderDetails[]> {
    return this.httpClient.get<OrderDetails[]>(`${this.baseURL + "getorderbycustid"}/${id}`);
  }

  getOrderByHireId(id: number): Observable<OrderDetails> {
    return this.httpClient.get<OrderDetails>(`${this.baseURL + "getorder"}/${id}`);
  }


  startOrder(id: number, orderDetails: OrderDetails): Observable<Object> {
    console.log("inside service : ========" + orderDetails);
    return this.httpClient.put(`${this.baseURL + "orderstart"}/${id}`, orderDetails);
  }

  EndOrder(id: number, orderDetails: OrderDetails): Observable<Object> {
    console.log("inside service : ========" + orderDetails);
    return this.httpClient.put(`${this.baseURL + "orderend"}/${id}`, orderDetails);
  }

  getOrderDetails(): Observable<OrderDetails[]> {
    return this.httpClient.get<OrderDetails[]>(`${this.baseURL + "getallorder"}`);
  }

  getOrderByEmployeeId(id: number): Observable<OrderDetails[]> {
    return this.httpClient.get<OrderDetails[]>(`${this.baseURL + "getorderbyempid"}/${id}`);
  }

  rejectOrder(id: number): Observable<OrderDetails[]> {
    return this.httpClient.get<OrderDetails[]>(`${this.baseURL + "rejectorder"}/${id}`);
  }

  getEmployeeByOrderStatus(id: number): Observable<OrderDetails[]> {
    return this.httpClient.get<OrderDetails[]>(`${this.baseURL + "getstatus"}/${id}`);
  }

}
