export class Customer {
    customerId: number;
    customerName: string;
    customerEmail: string;
    customerPassword: string;
    customerAddress: number;
    customerAadharNumber: number;
    customerDOB: string;
    customerContact: string;
    customerCity: string;
    customerGender: string;
}
