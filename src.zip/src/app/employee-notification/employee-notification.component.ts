import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { OrderDetails } from '../order-details';
import { OrderDetailsService } from '../order-details.service';
import { ProfessionserviceService } from '../professionservice.service';

@Component({
  selector: 'app-employee-notification',
  templateUrl: './employee-notification.component.html',
  styleUrls: ['./employee-notification.component.css']
})
export class EmployeeNotificationComponent implements OnInit {

  profession: any;
  mailId: string;
  order: OrderDetails;
  orders: OrderDetails[];
  undoneorders = false;
  emp: Employee[];
  employee: Employee = new Employee();
  customer: Customer = new Customer();
  constructor(private employeeService: EmployeeService,
    private router: Router,
    private customerService: CustomerService,
    private orderDetailsService: OrderDetailsService,
    private professionService: ProfessionserviceService) { }

  ngOnInit(): void {
    this.mailId = sessionStorage.getItem('sid');
    // console.log("mailId : == > " + this.mailId);

    if (this.mailId == null) {
      window.location.assign('elogin');
    } else {
      this.employeeService.getEmployeeByEmail(this.mailId).subscribe(data => {
        this.employee = data;
        this.orderDetailsService.getEmployeeByOrderStatus(this.employee.employeeId).subscribe(data => {
          this.orders = data;
          if (this.orders.length === 0) {
            (<HTMLInputElement>document.getElementById('notificationlist')).innerHTML = "No New Notifications";
            (<HTMLInputElement>document.getElementById('notificationlist')).style.fontSize = "50px";
            (<HTMLInputElement>document.getElementById('notificationlist')).style.textAlign = "center";
            (<HTMLInputElement>document.getElementById('notificationlist')).style.color = "red";
          }
          for (let i = 0; i < this.orders.length; i++) {
            const element = this.orders[i];
            this.customerService.getCustomerById(element.customerId).subscribe(data => {
              this.customer = data;
              this.orders[i].customerName = this.customer.customerName;
              this.orders[i].customerContact = this.customer.customerContact;
            })
          }
        })

      },
        error => console.log("error" + error)

      );
    }
  }

  rejectOrder(hireid: number) {
    console.log("reject btn=>" + hireid);
    this.orderDetailsService.rejectOrder(hireid).subscribe(data => {
      this.router.navigate(['ehome/employeeorderlist']);
    },
      error => console.log(error)
    );
  }
}


