export class OrderDetails {
    hireId: number;
    employeeId: number;
    customerId: number;
    hireDate: string;
    basicSal: number;
    totalAmount: number;
    startTime: string;
    endTime: string;
    status: string;
    employeeName: string;
    professionName: string;
    employeeContact: string;
    customerName: string;
    customerContact: string;
}
