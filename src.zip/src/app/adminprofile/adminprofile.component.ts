import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-adminprofile',
  templateUrl: './adminprofile.component.html',
  styleUrls: ['./adminprofile.component.css']
})
export class AdminprofileComponent implements OnInit {

  admin: Admin = new Admin();
  constructor(private adminServie: AdminService) { }

  ngOnInit(): void {
    var emailId = sessionStorage.getItem('sid');
    console.log(emailId);
    if (emailId === null) {
      window.location.assign("/ulogin")
      // this.router.navigate['ulogin'];
    } else {
      this.getAdmin();
    }
  }
  getAdmin() {
    let mailId = sessionStorage.getItem('sid');
    this.adminServie.getAdminByEmail(mailId).subscribe(data => {
      this.admin = data;
      // this.customers = data;
      console.log(this.admin);
    },
      error => console.log(error)
    );
  }

}
