import { TestBed } from '@angular/core/testing';

import { FeedbackModelService } from './feedback-model.service';

describe('FeedbackModelService', () => {
  let service: FeedbackModelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FeedbackModelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
