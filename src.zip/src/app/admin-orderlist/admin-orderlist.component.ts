import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Admin } from '../admin';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { OrderDetails } from '../order-details';
import { OrderDetailsService } from '../order-details.service';
import { Profession } from '../profession';
import { ProfessionserviceService } from '../professionservice.service';

@Component({
  selector: 'app-admin-orderlist',
  templateUrl: './admin-orderlist.component.html',
  styleUrls: ['./admin-orderlist.component.css']
})
export class AdminOrderlistComponent implements OnInit {

  admin: Admin = new Admin();
  orders: OrderDetails[];
  employee: Employee = new Employee();
  customer: Customer = new Customer();
  profession: Profession = new Profession();
  constructor(private orderDetailsService: OrderDetailsService,
    private employeeService: EmployeeService,
    private customerService: CustomerService,
    private professionService: ProfessionserviceService,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    let mailId = sessionStorage.getItem('sid');
    if (mailId == null) {
      window.location.assign('home');
    } else {
      this.orderDetailsService.getOrderDetails().subscribe(data => {
        this.orders = data;
        console.log(this.orders);
        for (let i = 0; i < this.orders.length; i++) {
          this.employee.employeeId = this.orders[i].employeeId;
          this.employeeService.getEmployeeById(this.employee.employeeId).subscribe(data => {
            this.employee = data;
            this.orders[i].employeeName = this.employee.employeeName;
            this.profession.professionId = this.employee.professionId;
            this.professionService.getProfessionById(this.profession.professionId).subscribe(data => {
              this.profession = data;
              this.orders[i].professionName = this.profession.professionName;
            })
          })
          this.customer.customerId = this.orders[i].customerId;
          this.customerService.getCustomerById(this.customer.customerId).subscribe(data => {
            this.customer = data;
            this.orders[i].customerName = this.customer.customerName;
          })
        }
      },
        error => console.log(error)
      );
    }
  }

}
