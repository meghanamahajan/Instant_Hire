import { elementEventFullName } from '@angular/compiler/src/view_compiler/view_compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { OrderDetails } from '../order-details';
import { OrderDetailsService } from '../order-details.service';

@Component({
  selector: 'app-adminhomepage',
  templateUrl: './adminhomepage.component.html',
  styleUrls: ['./adminhomepage.component.css']
})
export class AdminhomepageComponent implements OnInit {

  count: number = 0;
  employees: Employee[];
  employee: Employee;
  constructor(private router: Router,
    private employeeService: EmployeeService,
    private orderDetailsService: OrderDetailsService) { }

  ngOnInit(): void {
    var emailId = sessionStorage.getItem('sid');
    console.log(emailId);
    if (emailId === null && sessionStorage.getItem('type') === "admin") {
      window.location.assign("/alogin")
      // this.router.navigate['ulogin'];
    }
    this.getNewEmployee();
  }

  logout() {
    sessionStorage.removeItem('sid');
    sessionStorage.removeItem('type');
    this.router.navigate(['home']);
  }
  getEmployees() {
    let cat = (<HTMLInputElement>document.getElementById('getProfession')).value;
    let catId;
    switch (cat) {
      case 'carpenter': catId = 1;
        break;
      case 'driver': catId = 2;
        break;
      case 'painter': catId = 3;
        break;
      case 'event planner': catId = 4;
        break;
      case 'chef': catId = 5;
        break;
      case 'plumber': catId = 6;
        break;
      default: catId = 1;
        break;
    }
    console.log(catId);
    this.router.navigate(['ahome/professional-emp', catId]);

  }
  getNewEmployee() {
    this.employeeService.getEmployeesList().subscribe(data => {
      this.employees = data;
      for (let i = 0; i < this.employees.length; i++) {
        this.employee = this.employees[i];
        if (this.employee.employeeRating === 0) {
          this.count++;
          if (this.count == 0) {
            (<HTMLInputElement>document.getElementById('notification')).style.display = "none";
          } else {
            (<HTMLInputElement>document.getElementById('notification')).innerHTML = this.count.toString();
          }
        }
      }
    },
      error => this.router.navigate(['404'])
    );
  }

}
