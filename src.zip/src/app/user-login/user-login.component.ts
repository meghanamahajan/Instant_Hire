import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service'
import { Customer } from '../customer';


@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  public finalcheck = 1;
  public invalid = false;

  customer: Customer = new Customer();
  constructor(private customerservice: CustomerService,
    private router: Router) { }


  ngOnInit(): void {
  }

  validate() {
    let emailId = (<HTMLInputElement>document.getElementById('customerEmail')).value;
    let password = (<HTMLInputElement>document.getElementById('customerPassword')).value;

    if (emailId === "") {
      document.querySelector<HTMLElement>("#customerEmail").style.border = "1px solid red";
      this.finalcheck = 0;
    }

    if (password === "") {
      document.querySelector<HTMLElement>("#customerPassword").style.border = "1px solid red";
      this.finalcheck = 0;
    }

    if (this.finalcheck === 0) {
      return;
    } else {
      this.Custlogin();
    }


  }

  Custlogin() {
    this.customerservice.checkCustomer(this.customer).subscribe(data => {
      console.log(data);
      sessionStorage.setItem('sid', this.customer.customerEmail);
      sessionStorage.setItem('type', "customer");
      window.alert("Successfully Login!!!!!!!!!!!!!!!!!");
      this.router.navigate(['uhome']);
    },
      error => this.invalid = true
    );
  }

  onSubmit() {
    console.log(this.customer);
    this.validate();
  }


}
