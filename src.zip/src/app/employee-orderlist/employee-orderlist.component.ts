import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { OrderDetails } from '../order-details';
import { OrderDetailsService } from '../order-details.service';
import { ProfessionserviceService } from '../professionservice.service';

@Component({
  selector: 'app-employee-orderlist',
  templateUrl: './employee-orderlist.component.html',
  styleUrls: ['./employee-orderlist.component.css']
})
export class EmployeeOrderlistComponent implements OnInit {

  profession: any;
  mailId: string;
  orders: OrderDetails[];
  emp: Employee[];
  employee: Employee = new Employee();
  customer: Customer = new Customer();
  constructor(private employeeService: EmployeeService,
    private router: Router,
    private customerService: CustomerService,
    private OrderDetailsService: OrderDetailsService,
    private professionService: ProfessionserviceService) { }

  ngOnInit(): void {
    this.mailId = sessionStorage.getItem('sid');
    console.log("mailId : == > " + this.mailId);
    if (this.mailId == null) {
      window.location.assign('ulogin');
    } else {
      this.employeeService.getEmployeeByEmail(this.mailId).subscribe(data => {
        this.employee = data;
        console.log("inside employee object : " + this.employee.employeeId);
        this.OrderDetailsService.getOrderByEmployeeId(this.employee.employeeId).subscribe(data => {
          this.orders = data;
          console.log(this.orders);
          for (let i = 0; i < this.orders.length; i++) {
            console.log("cust id => " + this.orders[i].customerId);
            this.customer.customerId = this.orders[i].customerId;
            this.customerService.getCustomerById(this.customer.customerId).subscribe(data => {
              this.customer = data;
              console.log("customerName = > " + this.customer.customerName);
              this.orders[i].customerName = this.customer.customerName;
              this.orders[i].customerContact = this.customer.customerContact;
            });
          }
        })
      },
        error => console.log("error" + error)
      );
    }
  }

}
