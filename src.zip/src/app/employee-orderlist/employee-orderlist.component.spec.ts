import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeOrderlistComponent } from './employee-orderlist.component';

describe('EmployeeOrderlistComponent', () => {
  let component: EmployeeOrderlistComponent;
  let fixture: ComponentFixture<EmployeeOrderlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeOrderlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeOrderlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
