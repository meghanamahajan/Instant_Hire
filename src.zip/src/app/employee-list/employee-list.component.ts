import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  imgid: any;
  retrievedImage: any;
  retrieveResonse: any;
  base64Data: any;
  employees: Employee[];
  constructor(private employeeService: EmployeeService,
    private router: Router,
    private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.getEmployees();
  }

  private getEmployees() {
    this.employeeService.getEmployeesList().subscribe(data => {
      console.log(data);
      this.employees = data;
      for (let i = 0; i < this.employees.length; i++) {
        this.imgid = this.employees[i].employeeId;
        this.httpClient.get('http://localhost:8080/instanthire/image/show/' + this.imgid)
          .subscribe(
            res => {
              this.retrieveResonse = res;
              this.base64Data = this.retrieveResonse.picByte;
              this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
              this.employees[i].image = this.retrievedImage;
            }
          );
      }
    });
  }

  gotoPage(empId: number) {
    if (sessionStorage.getItem('type') === "admin") {
      this.router.navigate(['/ahome/viewemp', empId]);
    } else {
      this.router.navigate(['/uhome/confirm-employee', empId]);
    }
  }

  getEmployees1() {
    let cat = (<HTMLInputElement>document.getElementById('getProfession')).value;
    let catId;
    switch (cat) {
      case 'carpenter': catId = 1;
        break;
      case 'driver': catId = 2;
        break;
      case 'painter': catId = 3;
        break;
      case 'event planner': catId = 4;
        break;
      case 'chef': catId = 5;
        break;
      case 'plumber': catId = 6;
        break;
      default: catId = 1;
        break;
    }
    console.log(catId);
    this.router.navigate(['ahome/professional-emp', catId]);

  }

  serachbyCity() {
    let city = (<HTMLInputElement>document.getElementById('employeeCity')).value;
    this.employeeService.getEmployeeByCity(city).subscribe(data => {
      // this.employee = data;
      this.router.navigate(['uhome/empcity', city]);
    },
      error => this.router.navigate(['uhome/emplist'])
    );
  }

}




