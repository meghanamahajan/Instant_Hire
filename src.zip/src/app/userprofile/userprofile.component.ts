import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
  // customers: Customer[];
  customer: Customer = new Customer();
  constructor(private customerServie: CustomerService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    var emailId = sessionStorage.getItem('sid');
    console.log(emailId);
    if (emailId === null) {
      window.location.assign("/ulogin")
      // this.router.navigate['ulogin'];
    } else {
      this.getUser();
    }
  }

  getUser() {
    let mailId = sessionStorage.getItem('sid');
    this.customerServie.getCustomerByEmail(mailId).subscribe(data => {
      this.customer = data;
      // this.customers = data;
      console.log(Customer);
    },
      error => console.log(error)
    );
  }

  updateCustomer(customerId: number) {
    this.router.navigate(['/uhome/update-customer', customerId]);
  }

}
