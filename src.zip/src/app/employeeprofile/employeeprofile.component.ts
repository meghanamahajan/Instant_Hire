import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employeeprofile',
  templateUrl: './employeeprofile.component.html',
  styleUrls: ['./employeeprofile.component.css']
})
export class EmployeeprofileComponent implements OnInit {

  imgid: any;
  retrievedImage: any;
  retrieveResonse: any;
  base64Data: any;
  cid: number;
  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,
    private router: Router,
    private httpClient: HttpClient) { }

  ngOnInit(): void {
    var emailId = sessionStorage.getItem('sid');
    console.log(emailId);
    if (emailId === null) {
      window.location.assign("/ulogin")
      // this.router.navigate['ulogin'];
    } else {
      this.getEmployee();
    }
  }

  getEmployee() {
    let mailId = sessionStorage.getItem('sid');
    this.employeeService.getEmployeeByEmail(mailId).subscribe(data => {
      this.employee = data;
      // this.customers = data;
      console.log(this.employee);
      this.imgid = this.employee.employeeId;
      this.httpClient.get('http://localhost:8080/instanthire/image/show/' + this.imgid)
        .subscribe(
          res => {
            this.retrieveResonse = res;
            this.base64Data = this.retrieveResonse.picByte;
            this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
            this.employee.image = this.retrievedImage;
          }
        );
    },
      error => this.router.navigate(['404'])
    );
  }

  updateEmployee(id: number) {
    this.router.navigate(['/ehome/update-employee', id]);
  }


}
