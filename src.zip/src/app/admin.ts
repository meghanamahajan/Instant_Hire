export class Admin {
    adminId: number;
    adminName: string;
    adminPass: string;
    adminEmail: string;
    adminContact: string;
    selfOTP: number;
    generatedOTP: number;
}
