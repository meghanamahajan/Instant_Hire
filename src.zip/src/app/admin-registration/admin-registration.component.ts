import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-registration',
  templateUrl: './admin-registration.component.html',
  styleUrls: ['./admin-registration.component.css']
})
export class AdminRegistrationComponent implements OnInit {

  admin: Admin = new Admin();

  constructor(private adminService: AdminService,
    private router: Router) { }

  ngOnInit(): void {
  }

  adminRegister() {
    this.adminService.addAdmin(this.admin).subscribe(data => {
      this.router.navigate(['alogin']);
    },
      error => console.log(error)
    );
  }

  validateAdmin() {

    let finalCheck = 1;

    /**Fetching values from input box */
    let fullName = (<HTMLInputElement>document.getElementById('fullName')).value;
    let contactNo = (<HTMLInputElement>document.getElementById('contactNo')).value;
    let emailId = (<HTMLInputElement>document.getElementById('emailId')).value;
    let password = (<HTMLInputElement>document.getElementById('password')).value;
    let confirmPassword = (<HTMLInputElement>document.getElementById('confirmPassword')).value;

    /**Blank input box Validation */
    if (fullName === "") {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid red";
    }
    if (contactNo === "") {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid red";
    }

    if (emailId === "") {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid red";
    }

    if (password === "") {
      document.querySelector<HTMLElement>("#password").style.border = "1px solid red";
    }
    if (confirmPassword === "") {
      document.querySelector<HTMLElement>("#confirmPassword").style.border = "1px solid red";
    }


    /** Regex Pattern of all input data */
    let fullNamec = /^[a-zA-z ]{3,40}$/;
    let contactNoc = /^[0-9]{10}$/;
    let emailIdc = /^[A-Za-z0-9._]{3,}@[A-Za-z]{3,}[.]{1}[[A-Za-z.]{2,6}$/;
    let passwordc = /^(?=.*[0-9])(?=.*[!@#%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/;


    /**Matching the Pattern and fetched values */
    if (fullName.match(fullNamec)) {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg").innerHTML = "Please enter full name*";
      finalCheck = 0;
    }
    if (contactNo.match(contactNoc)) {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg1").innerHTML = "Only 10 digit number required*";
      finalCheck = 0;
    }
    if (emailId.match(emailIdc)) {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg3").innerHTML = "Please Enter Correct Email Id*";
      finalCheck = 0;
    }
    if (password.match(passwordc)) {
      document.querySelector<HTMLElement>("#password").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg4").innerHTML = "Please Enter atleast 1 special char and 1 number min 8 chars*";
      finalCheck = 0;
    }
    if (password === confirmPassword) {
      document.querySelector<HTMLElement>("#confirmPassword").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg5").innerHTML = "Please check reentered password*";
      finalCheck = 0;
    }

    //before insert into database
    if (finalCheck === 0) {
      return;
    } else {
      this.adminRegister();

    }
  }

  onSubmit() {
    this.validateAdmin();
    // console.log(this.admin);

  }

}
