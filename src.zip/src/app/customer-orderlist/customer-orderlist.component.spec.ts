import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerOrderlistComponent } from './customer-orderlist.component';

describe('CustomerOrderlistComponent', () => {
  let component: CustomerOrderlistComponent;
  let fixture: ComponentFixture<CustomerOrderlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerOrderlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerOrderlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
