import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { OrderDetails } from '../order-details';
import { OrderDetailsService } from '../order-details.service';
import { ProfessionserviceService } from '../professionservice.service';

@Component({
  selector: 'app-customer-orderlist',
  templateUrl: './customer-orderlist.component.html',
  styleUrls: ['./customer-orderlist.component.css']
})
export class CustomerOrderlistComponent implements OnInit {
  profession: any;
  mailId: string;
  orders: OrderDetails[];
  emp: Employee[];
  employee: Employee = new Employee();
  customer: Customer = new Customer();
  constructor(private employeeService: EmployeeService,
    private router: Router,
    private customerService: CustomerService,
    private OrderDetailsService: OrderDetailsService,
    private professionService: ProfessionserviceService) { }

  ngOnInit(): void {
    this.mailId = sessionStorage.getItem('sid');
    console.log("mailId : == > " + this.mailId);
    if (this.mailId == null) {
      window.location.assign('ulogin');
    } else {
      this.customerService.getCustomerByEmail(this.mailId).subscribe(data => {
        this.customer = data;
        console.log("inside customer object : " + this.customer.customerId);
        ////////////////////////////
        this.OrderDetailsService.getOrderByCustomerId(this.customer.customerId).subscribe(data => {
          this.orders = data;
          console.log(this.orders);
          for (let i = 0; i < this.orders.length; i++) {
            console.log("emp id => " + this.orders[i].employeeId);
            this.employee.employeeId = this.orders[i].employeeId;
            this.employeeService.getEmployeeById(this.employee.employeeId).subscribe(data => {
              this.employee = data;
              console.log("empname = > " + this.employee.employeeName);
              this.orders[i].employeeName = this.employee.employeeName;
              this.orders[i].employeeContact = this.employee.employeeContact;
              this.professionService.getProfessionById(this.employee.professionId).subscribe(data => {
                this.profession = data;
                console.log("profession====>" + this.profession.professionName);
                this.orders[i].professionName = this.profession.professionName;
              })
            });
          }
          ///////////////////////////////////////////////////////////

        })
      },
        error => console.log("error" + error)
      );

    }

  }

  startWorking(startid: number) {
    console.log("after start : ========");
    this.router.navigate(['uhome/order-reciept/', startid]);

    // this.OrderDetailsService.startOrder(startid, o).subscribe(data => {
    //   this.router.navigate(['uhome/customerorderlist']);
    // },
    //   error => console.log("error"));
  }

  endWorking(id: number) {

  }

}



// let mailId = sessionStorage.getItem('sid');
    // if (mailId === null) {
    //   window.location.assign('/ulogin');
    // } else {
    //   this.customerService.getCustomerByEmail(mailId).subscribe(data => {
    //     this.customer = data;
    //     console.log("==============================>" + this.customer);
    //     // this.cid = this.customer.customerId;
    //   },
    //     error => this.router.navigate(['404'])
    //   );

    //   console.log("====================================>" + this.customer.customerId);
    //   this.OrderDetailsService.getOrderByCustomerId(2).subscribe(data => {
    //     this.orders = data;
    //     console.log(this.orders);
    //     // this.eid = this.orders[data].employeeId;

    //   },
    //     // error => this.router.navigate(['404'])
    //     error => console.log(error)
    //   );

    //   // this.employeeService.getEmployeeById(this.employee.employeeId).subscribe(data => {
    //   //   this.employee = data;
    //   // },
    //   //   // error => this.router.navigate(['404'])
    //   //   error => console.log(error)
    //   // );



    // }