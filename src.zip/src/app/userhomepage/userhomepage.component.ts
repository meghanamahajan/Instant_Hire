import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Profession } from '../profession';
import { ProfessionserviceService } from '../professionservice.service';

@Component({
  selector: 'app-userhomepage',
  templateUrl: './userhomepage.component.html',
  styleUrls: ['./userhomepage.component.css']
})
export class UserhomepageComponent implements OnInit {

  professions: Profession[]

  constructor(private router: Router,
    private professionService: ProfessionserviceService) { }

  ngOnInit(): void {
    var emailId = sessionStorage.getItem('sid');
    console.log(emailId);
    if (emailId === null) {
      window.location.assign("/ulogin")
      // this.router.navigate['ulogin'];
    } else {
      this.professionService.getProfessions().subscribe(data => {
        console.log(data);
        this.professions = data;
        var btns = document.getElementsByClassName("activetag");

        // Loop through the buttons and add the active class to the current/clicked button
        for (let i = 0; i < btns.length; i++) {
          btns[i].addEventListener("click", function () {
            var current = document.getElementsByClassName("active");
            current[0].className = current[0].className.replace(" active", "");
            this.className += " active";
          });
        }
      });
    }
  }

  logoutHere() {
    // confirm("Do you want to logout???");
    // const ab: any = sessionStorage.key;
    console.log("logout");
    sessionStorage.removeItem('sid');
    this.router.navigate(['home']);
  }
}
