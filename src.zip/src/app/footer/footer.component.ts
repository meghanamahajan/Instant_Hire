import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FeedbackModel } from '../feedback-model';
import { FeedbackModelService } from '../feedback-model.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  feedbackModel: FeedbackModel = new FeedbackModel();
  constructor(private router: Router,
    private feedbackModelService: FeedbackModelService) { }

  ngOnInit(): void {
  }

  onsubmit() {
    console.log(this.feedbackModel.msg + " " + this.feedbackModel.emailId);
    this.feedbackModelService.addFeedback(this.feedbackModel).subscribe(data => {
      console.log("data = >" + data);
      window.alert("done");
      (<HTMLInputElement>document.querySelector("#emailId")).value = "";
      (<HTMLInputElement>document.querySelector("#msg")).value = "";
      if (sessionStorage.getItem('type') === "customer") {
        this.router.navigate(['uhome']);
      } else if (sessionStorage.getItem('type') === "admin") {
        this.router.navigate(['ahome']);
      } else if (sessionStorage.getItem('type') === "employee") {
        this.router.navigate(['ehome/employeeorderlist']);
      } else {
        this.router.navigate(['home']);
      }
    },
      error => window.alert("please try again!!!!!!!!")
    );


  }

}
