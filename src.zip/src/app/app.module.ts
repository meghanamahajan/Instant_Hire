import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { EmployeeLoginComponent } from './employee-login/employee-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { HttpClientModule } from '@angular/common/http';
import { AdminRegistrationComponent } from './admin-registration/admin-registration.component';
import { EmployeeRegistrationComponent } from './employee-registration/employee-registration.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { HomepageComponent } from './homepage/homepage.component';
import { UserhomepageComponent } from './userhomepage/userhomepage.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { ProfessionalEmployeesComponent } from './professional-employees/professional-employees.component';
import { ConfirmEmployeeComponent } from './confirm-employee/confirm-employee.component';
import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { EmployeehomepageComponent } from './employeehomepage/employeehomepage.component';
import { EmployeeprofileComponent } from './employeeprofile/employeeprofile.component';
import { CustomerOrderlistComponent } from './customer-orderlist/customer-orderlist.component';
import { OrderRecieptComponent } from './order-reciept/order-reciept.component';
import { AdminOrderlistComponent } from './admin-orderlist/admin-orderlist.component';
import { EmployeeOrderlistComponent } from './employee-orderlist/employee-orderlist.component';
import { CustforgotpassComponent } from './custforgotpass/custforgotpass.component';
import { EmployeeNotificationComponent } from './employee-notification/employee-notification.component';
import { NewEmployeesComponent } from './new-employees/new-employees.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { EmployeeforgotpassComponent } from './employeeforgotpass/employeeforgotpass.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { PaymentDetailsComponent } from './payment-details/payment-details.component';
import { PaymentReceiptComponent } from './payment-receipt/payment-receipt.component';
import { EmployeeByCityComponent } from './employee-by-city/employee-by-city.component';


@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    ErrorpageComponent,
    EmployeeLoginComponent,
    AdminLoginComponent,
    EmployeeListComponent,
    AdminRegistrationComponent,
    EmployeeRegistrationComponent,
    UserRegistrationComponent,
    UpdateEmployeeComponent,
    UpdateCustomerComponent,
    CustomerListComponent,
    HomepageComponent,
    UserhomepageComponent,
    UserprofileComponent,
    ProfessionalEmployeesComponent,
    ConfirmEmployeeComponent,
    AdminhomepageComponent,
    ViewCustomerComponent,
    ViewEmployeeComponent,
    AdminprofileComponent,
    EmployeehomepageComponent,
    EmployeeprofileComponent,
    CustomerOrderlistComponent,
    OrderRecieptComponent,
    AdminOrderlistComponent,
    EmployeeOrderlistComponent,
    CustforgotpassComponent,
    EmployeeNotificationComponent,
    NewEmployeesComponent,
    AboutUsComponent,
    ContactUsComponent,
    EmployeeforgotpassComponent,
    HeaderComponent,
    FooterComponent,
    PaymentDetailsComponent,
    PaymentReceiptComponent,
    EmployeeByCityComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
