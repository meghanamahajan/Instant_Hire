import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.css']
})
export class ViewEmployeeComponent implements OnInit {

  isAdmin: boolean = false;
  imgid: any;
  retrievedImage: any;
  retrieveResonse: any;
  base64Data: any;
  id: number;
  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router,
    private httpClient: HttpClient) { }

  ngOnInit(): void {
    var emailId = sessionStorage.getItem('sid');
    if (sessionStorage.getItem('type') === "admin") {
      this.isAdmin = true;
    } else {
      this.isAdmin = false;
    }
    console.log(emailId);
    if (emailId === null) {
      window.location.assign("/alogin")
    } else {
      this.getEmployee();
    }
  }
  getEmployee() {
    this.id = this.route.snapshot.params['id'];
    this.employeeService.getEmployeeById(this.id).subscribe(data => {
      this.employee = data;
      console.log(this.employee);

      this.imgid = this.employee.employeeId;
      this.httpClient.get('http://localhost:8080/instanthire/image/show/' + this.imgid)
        .subscribe(
          res => {
            this.retrieveResonse = res;
            this.base64Data = this.retrieveResonse.picByte;
            this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
            this.employee.image = this.retrievedImage;
          }
        );



    },
      error => this.router.navigate(['404'])
    )
  }

  deleteemployee(id: number) {
    window.confirm("Sure to delet ????");
    this.employeeService.deleteEmployee(id).subscribe(data => {
      console.log(data);
      this.router.navigate(['ahome/emplist']);
    });
  }

  updatevalue(id: number) {
    console.log(this.employee);
    this.employeeService.updateEmployee(id, this.employee).subscribe(data => {
      console.log(this.employee);
      window.alert("Rating is uploaded!!!!!!!!");
      this.router.navigate(['ahome/viewemp', this.employee.employeeId]);
    },
      error => window.alert("failed"));
  }

}
