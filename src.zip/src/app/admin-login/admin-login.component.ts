import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  public finalcheck = 1;

  public invalid = false;

  admin: Admin = new Admin();
  constructor(private adminService: AdminService,
    private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log(this.admin);
    this.validate();
  }
  validate() {
    let emailId = (<HTMLInputElement>document.getElementById('adminEmail')).value;
    let password = (<HTMLInputElement>document.getElementById('generatedOTP')).value;

    if (emailId === "") {
      document.querySelector<HTMLElement>("#adminEmail").style.border = "1px solid red";
      this.finalcheck = 0;
    }

    if (password === "") {
      document.querySelector<HTMLElement>("#admingeneratedOTP").style.border = "1px solid red";
      this.finalcheck = 0;
    }

    if (this.finalcheck === 0) {
      return;
    } else {
      this.adminlogin();
    }


  }


  adminlogin() {
    let otp = (<HTMLInputElement>document.getElementById("selfOTP")).value;
    console.log("form otp--->" + otp);
    if (otp.match(this.admin.selfOTP.toString())) {
      this.finalcheck = 0;
      console.log(this.admin.adminEmail + " " + this.admin.generatedOTP);
      this.adminService.checkAdmin(this.admin).subscribe(data => {
        console.log(data);
        sessionStorage.setItem('sid', this.admin.adminEmail);
        sessionStorage.setItem('type', "admin");
        this.router.navigate(['/ahome']);
      },
        // this.invalid = true;
        error => this.invalid = true
      );
    } else {
      window.alert("Please verify OTP !!!");
      this.router.navigate(['/alogin']);
    }
  }

  onsubmit() {
    // console.log(this.admin);
    // this.validate();
    this.admin.adminEmail = (<HTMLInputElement>document.getElementById('adminEmail')).value;
    console.log(this.admin.adminEmail);
    this.adminService.sendEmailadmin(this.admin).subscribe(data => {
      // this.router.navigate(['custrespass']);
      this.admin = data;
    },
      error => console.log(error)
    );
  }


}