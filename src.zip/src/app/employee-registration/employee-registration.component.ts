import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-registration',
  templateUrl: './employee-registration.component.html',
  styleUrls: ['./employee-registration.component.css']
})
export class EmployeeRegistrationComponent implements OnInit {

  //for img
  eid: number;
  imageName: any;
  selectedFile: any;
  base64Data: any;
  retrievedImage: any;
  message: string;
  retrieveResonse: any;
  empobj: Employee;
  /////////////////////////

  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,
    private router: Router,
    private httpClient: HttpClient) { }

  ngOnInit(): void {

  }

  employeeRegister() {
    this.employeeService.addEmployee(this.employee).subscribe(data => {
      this.router.navigate(['elogin']);
    },
      error => console.log(error)
    );

  }

  validateEmployee() {
    let finalCheck = 1;

    /**Fetching values from input box */
    let fullName = (<HTMLInputElement>document.getElementById('fullName')).value;
    let gender = (<HTMLInputElement>document.getElementById('gender')).value;
    let dateOfBirth = (<HTMLInputElement>document.getElementById('dateOfBirth')).value;
    let contactNo = (<HTMLInputElement>document.getElementById('contactNo')).value;
    let AddharNo = (<HTMLInputElement>document.getElementById('AddharNo')).value;
    let address = (<HTMLInputElement>document.getElementById('address')).value;

    let profession = (<HTMLInputElement>document.getElementById('profession')).value;
    let experience = (<HTMLInputElement>document.getElementById('experience')).value;
    let city = (<HTMLInputElement>document.getElementById('city')).value;
    let profileImage = (<HTMLInputElement>document.getElementById('profileImage')).value;
    let noc = (<HTMLInputElement>document.getElementById('noc')).value;

    let emailId = (<HTMLInputElement>document.getElementById('emailId')).value;
    let password = (<HTMLInputElement>document.getElementById('password')).value;
    let confirmPassword = (<HTMLInputElement>document.getElementById('confirmPassword')).value;
    let basicSal = (<HTMLInputElement>document.getElementById('basicSal')).value;

    /**Blank input box Validation */
    if (fullName === "") {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid red";
    }
    if (gender === "") {
      document.querySelector<HTMLElement>("#gender").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#gender").style.border = "1px solid green";
    }
    if (dateOfBirth === "") {
      document.querySelector<HTMLElement>("#dateOfBirth").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#dateOfBirth").style.border = "1px solid green";
    }
    if (contactNo === "") {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid red";
    }
    if (AddharNo === "") {
      document.querySelector<HTMLElement>("#AddharNo").style.border = "1px solid red";
    }
    if (address === "") {
      document.querySelector<HTMLElement>("#address").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#address").style.border = "1px solid green";
    }
    if (basicSal === "") {
      document.querySelector<HTMLElement>("#basicSal").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#basicSal").style.border = "1px solid green";
    }


    if (profession === "") {
      document.querySelector<HTMLElement>("#profession").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#profession").style.border = "1px solid green";
    }
    if (experience === "") {
      document.querySelector<HTMLElement>("#experience").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#experience").style.border = "1px solid green";
    }
    if (city === "") {
      document.querySelector<HTMLElement>("#city").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#city").style.border = "1px solid green";
    }
    if (profileImage === "") {
      document.querySelector<HTMLElement>("#profileImage").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#profileImage").style.border = "1px solid green";
    }
    if (noc === "") {
      document.querySelector<HTMLElement>("#noc").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#noc").style.border = "1px solid green";
    }

    if (emailId === "") {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid red";
    }

    if (password === "") {
      document.querySelector<HTMLElement>("#password").style.border = "1px solid red";
    }
    if (confirmPassword === "") {
      document.querySelector<HTMLElement>("#confirmPassword").style.border = "1px solid red";
    }


    /** Regex Pattern of all input data */
    let fullNamec = /^[a-zA-Z ]{3,40}$/;
    let contactNoc = /^[0-9]{10}$/;
    let AddharNoc = /^[0-9]{12}$/;
    let emailIdc = /^[A-Za-z0-9._]{3,}@[A-Za-z]{3,}[.]{1}[[A-Za-z.]{2,6}$/;
    let passwordc = /^(?=.*[0-9])(?=.*[!@#%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/;


    /**Matching the Pattern and fetched values */
    if (fullName.match(fullNamec)) {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg").innerHTML = "Please enter full name*";
      finalCheck = 0;
    }
    if (contactNo.match(contactNoc)) {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg1").innerHTML = "Only 10 digit number required*";
      finalCheck = 0;
    }
    if (AddharNo.match(AddharNoc)) {
      document.querySelector<HTMLElement>("#AddharNo").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg2").innerHTML = "Only 12 digit Addhar number required*";
      finalCheck = 0;
    }
    if (emailId.match(emailIdc)) {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg3").innerHTML = "Please Enter Correct Email Id*";
      finalCheck = 0;
    }
    if (password.match(passwordc)) {
      document.querySelector<HTMLElement>("#password").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg4").innerHTML = "Please Enter atleast 1 special char and 1 number min 8 chars*";
      finalCheck = 0;
    }
    if (password === confirmPassword) {
      document.querySelector<HTMLElement>("#confirmPassword").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg5").innerHTML = "Please check reentered password*";
      finalCheck = 0;
    }

    //before insert into database
    if (finalCheck === 0) {
      return;
    } else {

      this.registerEmployee();

    }
    console.log(emailId, password, confirmPassword, gender, profession, profileImage);


  }

  registerEmployee() {
    this.employeeService.addEmployee(this.employee).subscribe(data => {
      console.log("inside register" + data);
      this.empobj = data;
      let imgurl = "http://localhost:8080/instanthire/image/upload"
      console.log("inside upload=======" + this.empobj.employeeId);
      console.log(this.selectedFile);
      const uploadImageData = new FormData();
      uploadImageData.append('imageFile', this.selectedFile, this.selectedFile.name);
      this.httpClient.post(`${imgurl}/${this.empobj.employeeId}`, uploadImageData, { observe: 'response' })
        .subscribe((response) => {
          // 
        });
    },
      // error => console.log(error)
    );
    this.router.navigate(['elogin']);
  }

  onSubmit() {

    console.log(this.employee);
    this.validateEmployee();
    // console.log("inside onsubmit =========>" + this.empobj.employeeId);
    // this.router.navigate(['elogin']);
    // this.onUpload(this.empobj.employeeId);


  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0];
  }

  onUpload(id: number) {
    // let imgurl = "http://localhost:8080/instanthire/image/upload"
    // console.log("inside upload=======" + id);
    // console.log(this.selectedFile);
    // const uploadImageData = new FormData();
    // uploadImageData.append('imageFile', this.selectedFile, this.selectedFile.name);
    // this.httpClient.post(`${imgurl}/${id}`, uploadImageData, { observe: 'response' })
    //   .subscribe((response) => {
    //     this.router.navigate(['elogin']);
    //   });

  }



}
