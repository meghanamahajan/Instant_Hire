import { FeedbackModel } from './feedback-model';

describe('FeedbackModel', () => {
  it('should create an instance', () => {
    expect(new FeedbackModel()).toBeTruthy();
  });
});
