import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { OrderDetails } from '../order-details';
import { OrderDetailsService } from '../order-details.service';
import { Profession } from '../profession';
import { ProfessionserviceService } from '../professionservice.service';

@Component({
  selector: 'app-order-reciept',
  templateUrl: './order-reciept.component.html',
  styleUrls: ['./order-reciept.component.css']
})
export class OrderRecieptComponent implements OnInit {
  imgid: any;
  retrievedImage: any;
  retrieveResonse: any;
  base64Data: any;
  employee: Employee = new Employee();
  profession: Profession;
  id: number;
  order: OrderDetails = new OrderDetails();
  enableEdit: boolean;
  isdone: boolean = false;
  isrunning: boolean = true;
  constructor(private router: Router,
    private route: ActivatedRoute,
    private orderDetailsService: OrderDetailsService,
    private employeeService: EmployeeService,
    private professionService: ProfessionserviceService,
    private httpClient: HttpClient) { }

  ngOnInit(): void {
    let mailId = sessionStorage.getItem('sid');
    if (mailId == null) {
      window.location.assign('uhome');
    } else {
      this.id = this.route.snapshot.params['id'];
      this.orderDetailsService.getOrderByHireId(this.id).subscribe(data => {
        this.order = data;
        this.employeeService.getEmployeeById(this.order.employeeId).subscribe(data => {
          this.employee = data;
          this.getEmpImage(this.employee.employeeId);
          this.order.employeeName = this.employee.employeeName;
          this.order.employeeContact = this.employee.employeeContact;
          this.professionService.getProfessionById(this.employee.professionId).subscribe(data => {
            this.profession = data;
            this.order.professionName = this.profession.professionName;
            if (this.order.status === "undone") {
              this.enableEdit = true;
            } else if (this.order.status === "running") {
              this.isrunning = false;
            } else {
              this.isdone = true;
            }
          })
        });
      },
        error => console.log(error)
      );
    }



  }

  startWorking() {
    console.log("order ==== > " + this.order);
    this.enableEdit = false;
    this.orderDetailsService.startOrder(this.order.hireId, this.order).subscribe(data => {
      this.router.navigate(['uhome/customerorderlist']);
    },
      error => console.log("error"));
  }
  pay() {

  }

  onsubmit() {

  }
  stopWorking() {
    this.enableEdit = true;
    this.orderDetailsService.EndOrder(this.order.hireId, this.order).subscribe(data => {
      this.router.navigate(['uhome/customerorderlist']);
    },
      error => this.router.navigate(['404']));
  }

  getEmpImage(iid: number) {
    this.imgid = iid;
    this.httpClient.get('http://localhost:8080/instanthire/image/show/' + this.imgid)
      .subscribe(
        res => {
          this.retrieveResonse = res;
          this.base64Data = this.retrieveResonse.picByte;
          this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
          this.employee.image = this.retrievedImage;
        }
      );
  }

}
