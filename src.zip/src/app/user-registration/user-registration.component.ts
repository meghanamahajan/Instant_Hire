import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {

  customer: Customer = new Customer();
  constructor(private customerService: CustomerService,
    private router: Router) { }

  ngOnInit(): void {
  }

  validateUser() {
    let finalCheck = 1;

    /**Fetching values from input box */
    let fullName = (<HTMLInputElement>document.getElementById('fullName')).value;
    let gender = (<HTMLInputElement>document.getElementById('gender')).value;
    let dateOfBirth = (<HTMLInputElement>document.getElementById('dateOfBirth')).value;
    let contactNo = (<HTMLInputElement>document.getElementById('contactNo')).value;
    let AddharNo = (<HTMLInputElement>document.getElementById('AddharNo')).value;

    let city = (<HTMLInputElement>document.getElementById('city')).value;
    let address = (<HTMLInputElement>document.getElementById('address')).value;

    let emailId = (<HTMLInputElement>document.getElementById('emailId')).value;
    let password = (<HTMLInputElement>document.getElementById('password')).value;
    let confirmPassword = (<HTMLInputElement>document.getElementById('confirmPassword')).value;

    /**Blank input box Validation */
    if (fullName === "") {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid red";
    }
    if (gender === "") {
      document.querySelector<HTMLElement>("#gender").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#gender").style.border = "1px solid green";
    }
    if (dateOfBirth === "") {
      document.querySelector<HTMLElement>("#dateOfBirth").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#dateOfBirth").style.border = "1px solid green";
    }
    if (contactNo === "") {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid red";
    }
    if (AddharNo === "") {
      document.querySelector<HTMLElement>("#AddharNo").style.border = "1px solid red";
    }

    if (city === "") {
      document.querySelector<HTMLElement>("#city").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#city").style.border = "1px solid green";
    }
    if (address === "") {
      document.querySelector<HTMLElement>("#address").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#address").style.border = "1px solid green";
    }

    if (emailId === "") {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid red";
    }

    if (password === "") {
      document.querySelector<HTMLElement>("#password").style.border = "1px solid red";
    }
    if (confirmPassword === "") {
      document.querySelector<HTMLElement>("#confirmPassword").style.border = "1px solid red";
    }


    /** Regex Pattern of all input data */
    let fullNamec = /^[a-zA-z ]{3,40}$/;
    let contactNoc = /^[0-9]{10}$/;
    let AddharNoc = /^[0-9]{12}$/;
    let emailIdc = /^[A-Za-z0-9._]{3,}@[A-Za-z]{3,}[.]{1}[[A-Za-z.]{2,6}$/;
    let passwordc = /^(?=.*[0-9])(?=.*[!@#%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/;


    /**Matching the Pattern and fetched values */
    if (fullName.match(fullNamec)) {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg").innerHTML = "Please enter full name*";
      finalCheck = 0;
    }
    if (contactNo.match(contactNoc)) {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg1").innerHTML = "Only 10 digit number required*";
      finalCheck = 0;
    }
    if (AddharNo.match(AddharNoc)) {
      document.querySelector<HTMLElement>("#AddharNo").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg2").innerHTML = "Only 12 digit Addhar number required*";
      finalCheck = 0;
    }
    if (emailId.match(emailIdc)) {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg3").innerHTML = "Please Enter Correct Email Id*";
      finalCheck = 0;
    }
    if (password.match(passwordc)) {
      document.querySelector<HTMLElement>("#password").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg4").innerHTML = "Please Enter atleast 1 special char and 1 number min 8 chars*";
      finalCheck = 0;
    }
    if (password === confirmPassword) {
      document.querySelector<HTMLElement>("#confirmPassword").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg5").innerHTML = "Please check reentered password*";
      finalCheck = 0;
    }

    //before insert into database
    if (finalCheck === 0) {
      return;
    } else {
      /**======= DATA BASE CODE HERE ======= */
      console.log(this.customer);
      this.addCustomer();

    }

  }

  addCustomer() {
    this.customerService.registerCustomer(this.customer).subscribe(data => {
      this.router.navigate(['ulogin']);
    },
      error => console.log(error)
    );
  }

  onSubmit() {
    this.validateUser();

  }
}
