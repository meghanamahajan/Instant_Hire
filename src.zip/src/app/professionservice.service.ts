import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Profession } from './profession';

@Injectable({
  providedIn: 'root'
})
export class ProfessionserviceService {

  public baseURL = "http://localhost:8080/instanthire/profession/";
  constructor(private httpClient: HttpClient) { }

  //get professions list
  getProfessions(): Observable<Profession[]> {
    return this.httpClient.get<Profession[]>(`${this.baseURL + "professions"}`);
  }

  getProfessionById(id: number): Observable<Profession> {
    return this.httpClient.get<Profession>(`${this.baseURL + "getProfessionbyid"}/${id}`);
  }


}
