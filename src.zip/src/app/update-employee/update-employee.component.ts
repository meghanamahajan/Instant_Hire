import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  id: number;
  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.employeeService.getEmployeeById(this.id).subscribe(data => {
      this.employee = data;
    }, error => console.log(error));

  }

  validateEmployee() {
    let finalCheck = 1;

    /**Fetching values from input box */
    let fullName = (<HTMLInputElement>document.getElementById('fullName')).value;
    let contactNo = (<HTMLInputElement>document.getElementById('contactNo')).value;
    let emailId = (<HTMLInputElement>document.getElementById('emailId')).value;
    // let password = (<HTMLInputElement>document.getElementById('password')).value;
    // let confirmPassword = (<HTMLInputElement>document.getElementById('confirmPassword')).value;

    /**Blank input box Validation */
    if (fullName === "") {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid red";
    }
    if (contactNo === "") {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid red";
    }

    if (emailId === "") {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid red";
    }

    // if (password === "") {
    //   document.querySelector<HTMLElement>("#password").style.border = "1px solid red";
    // }
    // if (confirmPassword === "") {
    //   document.querySelector<HTMLElement>("#confirmPassword").style.border = "1px solid red";
    // }


    /** Regex Pattern of all input data */
    let fullNamec = /^[a-zA-z ]{3,40}$/;
    let contactNoc = /^[0-9]{10}$/;
    let emailIdc = /^[A-Za-z0-9._]{3,}@[A-Za-z]{3,}[.]{1}[[A-Za-z.]{2,6}$/;
    // let passwordc = /^(?=.*[0-9])(?=.*[!@#%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/;


    /**Matching the Pattern and fetched values */
    if (fullName.match(fullNamec)) {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg").innerHTML = "Please enter full name*";
      finalCheck = 0;
    }
    if (contactNo.match(contactNoc)) {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg1").innerHTML = "Only 10 digit number required*";
      finalCheck = 0;
    }
    if (emailId.match(emailIdc)) {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg3").innerHTML = "Please Enter Correct Email Id*";
      finalCheck = 0;
    }
    // if (password.match(passwordc)) {
    //   document.querySelector<HTMLElement>("#password").style.border = "1px solid green";
    // } else {
    //   document.querySelector<HTMLElement>("#errormsg4").innerHTML = "Please Enter atleast 1 special char and 1 number min 8 chars*";
    //   finalCheck = 0;
    // }
    // if (password === confirmPassword) {
    //   document.querySelector<HTMLElement>("#confirmPassword").style.border = "1px solid green";
    // } else {
    //   document.querySelector<HTMLElement>("#errormsg5").innerHTML = "Please check reentered password*";
    //   finalCheck = 0;
    // }

    //before insert into database
    if (finalCheck === 0) {
      return;
    } else {
      /**======= DATA BASE CODE HERE ======= */
      console.log(this.employee);
      this.updateEmployee();

    }
  }

  onSubmit() {
    this.validateEmployee()
  }

  updateEmployee() {
    this.employeeService.updateEmployee(this.id, this.employee).subscribe(data => {
      this.router.navigate(['ehome/eprofile']);
    },
      error => console.log("error"));
  }

}
