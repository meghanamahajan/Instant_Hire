export class Employee {
    employeeId: number;
    employeeName: string;
    employeeEmail: string;
    employeePassword: string;
    employeeContact: string;
    employeeAddress: string;
    employeeAadharNumber: string;
    employeeDOB: string;
    professionId: number;
    employeeExperiance: number;
    employeeImage: string;
    employeeNOC: string;
    employeeCity: string;
    employeeGender: string;
    employeeRating: number;
    professionName: string;
    basicSal: number;
    image: any;
}
