import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeforgotpassComponent } from './employeeforgotpass.component';

describe('EmployeeforgotpassComponent', () => {
  let component: EmployeeforgotpassComponent;
  let fixture: ComponentFixture<EmployeeforgotpassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeforgotpassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeforgotpassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
