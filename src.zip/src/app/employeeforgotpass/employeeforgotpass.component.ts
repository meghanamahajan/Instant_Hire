import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employeeforgotpass',
  templateUrl: './employeeforgotpass.component.html',
  styleUrls: ['./employeeforgotpass.component.css']
})
export class EmployeeforgotpassComponent implements OnInit {

  employee: Employee = new Employee();
  mailId: string;
  newpass: string;
  constructor(private employeeService: EmployeeService,
    private router: Router) { }

  ngOnInit(): void {
  }
  onsubmit() {
    // this.mailId = sessionStorage.getItem('sid');
    this.employee.employeeEmail = (<HTMLInputElement>document.getElementById('employeeEmail')).value;
    console.log(this.employee.employeeEmail);


    this.employeeService.sendEmailemp(this.employee).subscribe(data => {
      // this.router.navigate(['custrespass']);
      this.employee = data;
    },
      error => console.log(error)
    );
  }
  changepass() {
    let opass = (<HTMLInputElement>document.getElementById('employeePassword')).value;
    this.newpass = (<HTMLInputElement>document.getElementById('newpass')).value;
    // this.mailId = sessionStorage.getItem('sid');

    this.employeeService.getEmployeeByEmail(this.employee.employeeEmail).subscribe(data => {
      this.employee = data;
      console.log("after obj " + this.employee.employeeName);
      if (opass === this.employee.employeePassword) {
        console.log("pass matched==================" + this.employee.employeePassword);
        this.employee.employeePassword = this.newpass;
        this.employeeService.updateEmployee(this.employee.employeeId, this.employee).subscribe(data => {
          this.router.navigate(['elogin']);
        }, error => console.log(error));
      }


    }, error => console.log(error)
    );

  }

}
