import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { OrderDetails } from '../order-details';
import { OrderDetailsService } from '../order-details.service';

@Component({
  selector: 'app-employeehomepage',
  templateUrl: './employeehomepage.component.html',
  styleUrls: ['./employeehomepage.component.css']
})
// export class EmployeehomepageComponent implements OnInit {

// constructor(private router: Router) { }

// ngOnInit(): void {
//   var emailId = sessionStorage.getItem('sid');
//   console.log(emailId);
//   if (emailId === null) {
//     window.location.assign("/elogin")
//     // this.router.navigate['ulogin'];
//   } else {

//   }
// }
// logout() {
//   sessionStorage.removeItem('sid');
//   this.router.navigate(['home']);
// }

export class EmployeehomepageComponent implements OnInit {
  count: number = 0;
  emailId: any;
  employee: Employee = new Employee();
  orders: OrderDetails[];
  constructor(private router: Router,
    private employeeService: EmployeeService,
    private orderDetailsService: OrderDetailsService) { }

  ngOnInit(): void {
    this.emailId = sessionStorage.getItem('sid');
    console.log(this.emailId);
    if (this.emailId === null) {
      window.location.assign("/elogin")
      // this.router.navigate['ulogin'];
    } else {
      this.employeeService.getEmployeeByEmail(this.emailId).subscribe(data => {
        this.employee = data;
        // console.log("EmployeeId ====>" + this.employee.employeeId);
        this.orderDetailsService.getOrderByEmployeeId(this.employee.employeeId).subscribe(data => {
          this.orders = data;
          // console.log("Order Details====>" + this.orders[0].status);
          for (let i = 0; i < this.orders.length; i++) {
            // console.log(this.orders[i].status);
            if (this.orders[i].status === "undone") {
              this.count++;
            }
          }
          // console.log(this.count);
          if (this.count === 0) {
            (<HTMLInputElement>document.getElementById('notification')).style.display = "none";
          } else {
            (<HTMLInputElement>document.getElementById('notification')).innerHTML = this.count.toString();
          }
        },
          error => console.log(error)
        );
      },
        error => console.log(error)
      );
    }
  }



  logout() {
    sessionStorage.removeItem('sid');
    sessionStorage.removeItem('type');
    this.router.navigate(['home']);
  }


}


