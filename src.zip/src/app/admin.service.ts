import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private checkadminurl = "http://localhost:8080/instanthire/admin/checkadmin";

  private addAdminurl = "http://localhost:8080/instanthire/admin/addadmin";
  private getAdminURL = "http://localhost:8080/instanthire/admin/getadmin";
  constructor(private httpClient: HttpClient) { }

  checkAdmin(admin: Admin): Observable<Object> {
    return this.httpClient.post(`${this.checkadminurl}`, admin);
  }

  addAdmin(admin: Admin): Observable<Object> {
    return this.httpClient.post(`${this.addAdminurl}`, admin);
  }

  getAdminByEmail(mailId: string): Observable<Admin> {
    return this.httpClient.get<Admin>(`${this.getAdminURL}/${mailId}`,);
  }

  sendEmailadmin(mailId: Admin): Observable<Admin> {
    return this.httpClient.post<Admin>("http://localhost:8080/instanthire/admin/sendKeyByEmailadmin", mailId);
  }
}
