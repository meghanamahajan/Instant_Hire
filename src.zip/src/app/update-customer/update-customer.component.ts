import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {

  id: number;
  customer: Customer = new Customer();
  constructor(private customerService: CustomerService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    var emailId = sessionStorage.getItem('sid');
    console.log(emailId);
    if (emailId === null) {
      window.location.assign("/ulogin")
      // this.router.navigate['ulogin'];
    } else {
      this.id = this.route.snapshot.params['id'];

      this.customerService.getCustomerById(this.id).subscribe(data => {
        this.customer = data;
      },
        error => console.log(error)
      );
    }
  }
  onSubmit() {
    let finalCheck = 1;

    /* input box values */
    let fullName = (<HTMLInputElement>document.getElementById('fullName')).value;

    let dateOfBirth = (<HTMLInputElement>document.getElementById('dateOfBirth')).value;
    let contactNo = (<HTMLInputElement>document.getElementById('contactNo')).value;
    let AddharNo = (<HTMLInputElement>document.getElementById('AddharNo')).value;

    let city = (<HTMLInputElement>document.getElementById('city')).value;
    let address = (<HTMLInputElement>document.getElementById('address')).value;

    let emailId = (<HTMLInputElement>document.getElementById('emailId')).value;


    /**Blank input validation */
    if (fullName === "") {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid red";
    }

    if (dateOfBirth === "") {
      document.querySelector<HTMLElement>("#dateOfBirth").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#dateOfBirth").style.border = "1px solid green";
    }
    if (contactNo === "") {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid red";
    }
    if (AddharNo === "") {
      document.querySelector<HTMLElement>("#AddharNo").style.border = "1px solid red";
    }

    if (city === "") {
      document.querySelector<HTMLElement>("#city").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#city").style.border = "1px solid green";
    }
    if (address === "") {
      document.querySelector<HTMLElement>("#address").style.border = "1px solid red";
    } else {
      document.querySelector<HTMLElement>("#address").style.border = "1px solid green";
    }

    if (emailId === "") {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid red";
    }




    /** Regex Pattern */
    let fullNamec = /^[a-zA-z ]{3,40}$/;
    let contactNoc = /^[0-9]{10}$/;
    let AddharNoc = /^[0-9]{12}$/;
    let emailIdc = /^[A-Za-z0-9._]{3,}@[A-Za-z]{3,}[.]{1}[[A-Za-z.]{2,6}$/;



    /*pattern matching*/
    if (fullName.match(fullNamec)) {
      document.querySelector<HTMLElement>("#fullName").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg").innerHTML = "Please enter full name*";
      finalCheck = 0;
    }
    if (contactNo.match(contactNoc)) {
      document.querySelector<HTMLElement>("#contactNo").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg1").innerHTML = "Only 10 digit number required*";
      finalCheck = 0;
    }
    if (AddharNo.match(AddharNoc)) {
      document.querySelector<HTMLElement>("#AddharNo").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg2").innerHTML = "Only 12 digit Addhar number required*";
      finalCheck = 0;
    }
    if (emailId.match(emailIdc)) {
      document.querySelector<HTMLElement>("#emailId").style.border = "1px solid green";
    } else {
      document.querySelector<HTMLElement>("#errormsg3").innerHTML = "Please Enter Correct Email Id*";
      finalCheck = 0;
    }


    //before insert into database
    if (finalCheck === 0) {
      return;
    } else {
      this.customerService.updateCustomer(this.id, this.customer).subscribe(data => {
        this.router.navigate(['uhome']);
      },
        error => console.log("error"));
    }
  }

}
