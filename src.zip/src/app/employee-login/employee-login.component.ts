import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee-login',
  templateUrl: './employee-login.component.html',
  styleUrls: ['./employee-login.component.css']
})
export class EmployeeLoginComponent implements OnInit {
  public finalcheck = 1;

  public invalid = false;

  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,
    private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log(this.employee);
    this.validate();
  }

  validate() {
    let emailId = (<HTMLInputElement>document.getElementById('employeeEmail')).value;
    let password = (<HTMLInputElement>document.getElementById('employeePassword')).value;

    if (emailId === "") {
      document.querySelector<HTMLElement>("#employeeEmail").style.border = "1px solid red";
      this.finalcheck = 0;
    }

    if (password === "") {
      document.querySelector<HTMLElement>("#employeePassword").style.border = "1px solid red";
      this.finalcheck = 0;
    }

    if (this.finalcheck === 0) {
      return;
    } else {
      this.employeelogin();
    }
  }
  employeelogin() {
    this.employeeService.checkEmployee(this.employee).subscribe(data => {
      console.log(data);
      sessionStorage.setItem('sid', this.employee.employeeEmail);
      sessionStorage.setItem('type', "employee");
      this.router.navigate(['ehome/employeeorderlist']);
    },
      error => this.invalid = true
    );
  }

}
