import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfessionalEmployeesComponent } from './professional-employees.component';

describe('ProfessionalEmployeesComponent', () => {
  let component: ProfessionalEmployeesComponent;
  let fixture: ComponentFixture<ProfessionalEmployeesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfessionalEmployeesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfessionalEmployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
