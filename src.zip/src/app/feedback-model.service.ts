import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FeedbackModel } from './feedback-model';

@Injectable({
  providedIn: 'root'
})
export class FeedbackModelService {

  private baseURL = "http://localhost:8080/instanthire/feedback/";
  constructor(private httpClient: HttpClient) { }

  //add feedback from footer
  addFeedback(feedback: FeedbackModel): Observable<Object> {
    return this.httpClient.post(`${this.baseURL + "enquiry"}`, feedback);
  }
}
