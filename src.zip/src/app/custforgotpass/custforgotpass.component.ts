import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-custforgotpass',
  templateUrl: './custforgotpass.component.html',
  styleUrls: ['./custforgotpass.component.css']
})
export class CustforgotpassComponent implements OnInit {

  customer: Customer = new Customer();
  mailId: string;
  newpass: string;
  constructor(private customerService: CustomerService,
    private router: Router) { }

  ngOnInit(): void {
  }
  onsubmit() {
    // this.mailId = sessionStorage.getItem('sid');
    this.customer.customerEmail = (<HTMLInputElement>document.getElementById('customerEmail')).value;
    console.log(this.customer.customerEmail);


    this.customerService.sendEmail(this.customer).subscribe(data => {
      // this.router.navigate(['custrespass']);
      this.customer = data;
    },
      error => console.log(error)
    );
  }
  changepass() {
    let opass = (<HTMLInputElement>document.getElementById('customerPassword')).value;
    this.newpass = (<HTMLInputElement>document.getElementById('newpass')).value;
    // this.mailId = sessionStorage.getItem('sid');
    this.customerService.getCustomerByEmail(this.customer.customerEmail).subscribe(data => {
      this.customer = data;
      console.log("after obj " + this.customer.customerName);
      if (opass === this.customer.customerPassword) {
        console.log("pass matched==================" + this.customer.customerPassword);
        this.customer.customerPassword = this.newpass;
        this.customerService.updateCustomer(this.customer.customerId, this.customer).subscribe(data => {

          this.router.navigate(['ulogin']);
        }, error => console.log(error));
      }


    }, error => console.log(error)
    );

  }

}
