import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustforgotpassComponent } from './custforgotpass.component';

describe('CustforgotpassComponent', () => {
  let component: CustforgotpassComponent;
  let fixture: ComponentFixture<CustforgotpassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustforgotpassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustforgotpassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
