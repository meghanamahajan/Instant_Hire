export class FeedbackModel {
    feedbackId: number;
    emailId: string;
    msg: string;
    customerId: number;
    employeeId: number;
}
