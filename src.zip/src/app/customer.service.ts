import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private baseURL1 = "http://localhost:8080/instanthire/cust/";

  constructor(private httpClient: HttpClient) { }

  // login
  checkCustomer(customer: Customer): Observable<Object> {
    return this.httpClient.post(`${this.baseURL1 + "checkcust"}`, customer);
  }

  //register
  registerCustomer(customer: Customer): Observable<Object> {
    return this.httpClient.post(`${this.baseURL1 + "addcust"}`, customer);
  }

  //customer list
  getCustomerList(): Observable<Customer[]> {
    return this.httpClient.get<Customer[]>(`${this.baseURL1 + "custlist"}`);
  }

  //update emp
  updateCustomer(id: number, employee: Customer): Observable<Object> {
    return this.httpClient.put(`${this.baseURL1 + "updatecustomer"}/${id}`, employee);
  }

  getCustomerById(id: number): Observable<Customer> {
    return this.httpClient.get<Customer>(`${this.baseURL1 + "customers"}/${id}`);
  }

  //delete emp
  deleteCustomer(id: number): Observable<Object> {
    return this.httpClient.delete(`${this.baseURL1 + "deletecustomer"}/${id}`);
  }

  getCustomerByEmail(mailId: string): Observable<Customer> {
    return this.httpClient.get<Customer>(`${this.baseURL1 + "getcustbyemail"}/${mailId}`);
  }

  sendEmail(customer: Customer): Observable<Customer> {
    return this.httpClient.post<Customer>(`${this.baseURL1 + "sendKeyByEmail"}`, customer);
  }


}
