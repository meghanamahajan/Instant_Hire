import { OrderDetails } from './order-details';

describe('OrderDetails', () => {
  it('should create an instance', () => {
    expect(new OrderDetails()).toBeTruthy();
  });
});
