import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { PaymentDetails } from '../payment-details';

@Component({
  selector: 'app-payment-details',
  templateUrl: './payment-details.component.html',
  styleUrls: ['./payment-details.component.css']
})
export class PaymentDetailsComponent implements OnInit {

  paydet: PaymentDetails = new PaymentDetails();
  constructor(private httpClient: HttpClient) { }

  ngOnInit(): void {
  }

  onsubmit() {
    console.log("on submit =========" + this.paydet.CUST_ID);
    this.httpClient.post(`${"http://localhost:8080/submitPaymentDetail"}`, this.paydet).subscribe(data => {
      console.log("done");
    },
      error => console.log("error==========>" + error)
    );
  }



}
