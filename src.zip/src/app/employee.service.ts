import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private baseURL1 = "http://localhost:8080/instanthire/employee/";

  constructor(private httpClient: HttpClient) { }

  //login
  checkEmployee(employee: Employee): Observable<Object> {
    return this.httpClient.post(`${this.baseURL1 + "checkemployee"}`, employee);
  }

  //registration
  addEmployee(employee: Employee): Observable<any> {
    return this.httpClient.post(`${this.baseURL1 + "addemployee"}`, employee);
  }

  //all emp list
  getEmployeesList(): Observable<Employee[]> {
    return this.httpClient.get<Employee[]>(`${this.baseURL1 + "employees"}`);
  }

  //get one employee
  getEmployeeById(id: number): Observable<Employee> {
    return this.httpClient.get<Employee>(`${this.baseURL1 + "employees"}/${id}`);
  }

  //update emp
  updateEmployee(id: number, employee: Employee): Observable<Object> {
    return this.httpClient.put(`${this.baseURL1 + "updateemployee"}/${id}`, employee);
  }

  //delete emp
  deleteEmployee(id: number): Observable<Object> {
    return this.httpClient.delete(`${this.baseURL1 + "deleteemployee"}/${id}`);
  }

  //get emp by profession
  getEmployeeByProfession(id: number): Observable<Employee[]> {
    return this.httpClient.get<Employee[]>(`${this.baseURL1 + "employeebyprofession"}/${id}`);
  }

  getEmployeeByEmail(emailId: string): Observable<Employee> {
    return this.httpClient.get<Employee>(`${this.baseURL1 + "getempbyemail"}/${emailId}`);
  }

  getEmployeeByRating(): Observable<Employee[]> {
    return this.httpClient.get<Employee[]>(`${this.baseURL1 + "empbyrating"}`);
  }

  sendEmailemp(mailId: Employee): Observable<Employee> {
    return this.httpClient.post<Employee>(`${this.baseURL1 + "sendKeyByEmailee"}`, mailId);
  }

  getEmployeeByCity(city: string): Observable<Employee[]> {
    return this.httpClient.get<Employee[]>(`${this.baseURL1 + "getempbycity"}/${city}`);

  }



}
