export class Profession {
    professionId: number;
    professionName: string;
    professionDescription: string;
}
