import { PaymentDetails } from './payment-details';

describe('PaymentDetails', () => {
  it('should create an instance', () => {
    expect(new PaymentDetails()).toBeTruthy();
  });
});
